#include <stdio.h>

void call_function() {
  printf("Hello World!\n");
}
