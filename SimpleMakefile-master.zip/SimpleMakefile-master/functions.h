#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void call_function();

#endif // FUNCTIONS_H
