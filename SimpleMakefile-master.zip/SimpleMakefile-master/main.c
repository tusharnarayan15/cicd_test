#include "functions.h"

int main(int argc, char ** argv) {
  call_function();
  return 0;
}
